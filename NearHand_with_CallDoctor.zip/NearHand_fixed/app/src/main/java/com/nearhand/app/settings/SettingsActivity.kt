package com.nearhand.app.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nearhand.app.BaseActivity
import com.nearhand.app.databinding.ActivitySettingsBinding
import com.nearhand.app.databinding.ItemLanguageBinding
import com.nearhand.app.utils.LanguageUtils

class SettingsActivity : BaseActivity() {

    companion object {
        private const val PREFS_NAME            = "nearhand_prefs"
        private const val KEY_EMERGENCY_CONTACT = "emergency_contact"
    }

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // ── Emergency contact ──────────────────────────────────────────────
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        binding.etEmergencyContact.setText(
            prefs.getString(KEY_EMERGENCY_CONTACT, "")
        )
        binding.btnSaveContact.setOnClickListener {
            val number = binding.etEmergencyContact.text?.toString()?.trim() ?: ""
            prefs.edit().putString(KEY_EMERGENCY_CONTACT, number).apply()
            Toast.makeText(this, getString(com.nearhand.app.R.string.settings_emergency_contact_saved),
                Toast.LENGTH_SHORT).show()
        }

        // ── Language picker ────────────────────────────────────────────────
        val currentCode = LanguageUtils.getSavedLanguageCode(this)
        val adapter = LanguageAdapter(
            languages    = LanguageUtils.supportedLanguages,
            selectedCode = currentCode
        ) { selected ->
            LanguageUtils.saveLanguageCode(this, selected.code)
            val intent = packageManager.getLaunchIntentForPackage(packageName)!!
            intent.addFlags(
                android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK or
                android.content.Intent.FLAG_ACTIVITY_NEW_TASK
            )
            startActivity(intent)
            finishAffinity()
        }

        binding.recyclerLanguages.layoutManager = LinearLayoutManager(this)
        binding.recyclerLanguages.adapter = adapter
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed(); return true
    }
}

class LanguageAdapter(
    private val languages: List<LanguageUtils.Language>,
    private var selectedCode: String,
    private val onSelect: (LanguageUtils.Language) -> Unit
) : RecyclerView.Adapter<LanguageAdapter.VH>() {

    inner class VH(val binding: ItemLanguageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
        ItemLanguageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun getItemCount() = languages.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val lang = languages[position]
        holder.binding.tvLanguageName.text     = lang.nativeName
        holder.binding.tvLanguageSubtitle.text = lang.displayName
        holder.binding.radioButton.isChecked   = lang.code == selectedCode
        holder.itemView.setOnClickListener {
            selectedCode = lang.code
            notifyDataSetChanged()
            onSelect(lang)
        }
    }
}
