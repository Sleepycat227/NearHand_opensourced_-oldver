package com.nearhand.app.elder

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.nearhand.app.BaseActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nearhand.app.databinding.ActivityMyRequestsBinding
import com.nearhand.app.helper.RequestsAdapter
import com.nearhand.app.utils.FirebaseRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MyRequestsActivity : BaseActivity() {

    private lateinit var binding: ActivityMyRequestsBinding
    private lateinit var adapter: RequestsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyRequestsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        adapter = RequestsAdapter(isHelperView = false)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        lifecycleScope.launch {
            val uid = FirebaseRepository.currentUserId
            FirebaseRepository.getElderRequests(uid).collectLatest { requests ->
                adapter.submitList(requests)
                binding.tvEmpty.visibility = if (requests.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}
