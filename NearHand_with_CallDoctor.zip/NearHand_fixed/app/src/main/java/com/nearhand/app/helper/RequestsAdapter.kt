package com.nearhand.app.helper

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nearhand.app.databinding.ItemRequestBinding
import com.nearhand.app.model.HelpRequest
import com.nearhand.app.model.RequestType

class RequestsAdapter(
    private val isHelperView: Boolean,
    private val onItemClick: ((HelpRequest) -> Unit)? = null
) : ListAdapter<HelpRequest, RequestsAdapter.ViewHolder>(DIFF) {

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<HelpRequest>() {
            override fun areItemsTheSame(a: HelpRequest, b: HelpRequest) = a.id == b.id
            override fun areContentsTheSame(a: HelpRequest, b: HelpRequest) = a == b
        }
    }

    inner class ViewHolder(val binding: ItemRequestBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemRequestBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val request = getItem(position)
        val b = holder.binding

        val type = runCatching { RequestType.valueOf(request.type) }.getOrNull()
        b.tvEmoji.text       = type?.emoji ?: "🙏"
        b.tvType.text        = type?.displayName ?: request.type
        b.tvElderName.text   = request.elderName
        b.tvDescription.text = request.description.ifEmpty { "No additional details" }
        b.tvStatus.text      = request.status.replaceFirstChar { it.uppercase() }

        val statusColor = when (request.status) {
            "open"      -> android.R.color.holo_green_dark
            "accepted"  -> android.R.color.holo_blue_dark
            "completed" -> android.R.color.darker_gray
            else        -> android.R.color.darker_gray
        }
        b.tvStatus.setTextColor(holder.itemView.context.getColor(statusColor))

        if (isHelperView && request.status == "open") {
            holder.itemView.setOnClickListener { onItemClick?.invoke(request) }
        } else {
            holder.itemView.isClickable = false
        }
    }
}
