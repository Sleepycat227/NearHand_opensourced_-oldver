package com.nearhand.app

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import com.nearhand.app.utils.LanguageUtils

/**
 * All activities extend this instead of AppCompatActivity directly.
 * attachBaseContext is the correct place to inject a locale-wrapped Context —
 * it runs before setContentView, so all string resources are resolved in the
 * chosen language from the very first frame.
 */
open class BaseActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LanguageUtils.wrap(newBase))
    }
}
