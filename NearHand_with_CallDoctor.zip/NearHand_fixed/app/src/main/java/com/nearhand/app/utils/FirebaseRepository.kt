package com.nearhand.app.utils

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.nearhand.app.model.HelpRequest
import com.nearhand.app.model.Medication
import com.nearhand.app.model.User
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

object FirebaseRepository {

    private val auth get() = FirebaseAuth.getInstance()
    private val db   get() = FirebaseFirestore.getInstance()

    // ── Auth ──────────────────────────────────────────────────────────────────

    val currentUserId get() = auth.currentUser?.uid ?: ""
    val isLoggedIn    get() = auth.currentUser != null

    suspend fun register(email: String, password: String): Result<String> = runCatching {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        result.user?.uid ?: throw Exception("UID not found")
    }

    suspend fun login(email: String, password: String): Result<String> = runCatching {
        val result = auth.signInWithEmailAndPassword(email, password).await()
        result.user?.uid ?: throw Exception("UID not found")
    }

    fun logout() = auth.signOut()

    // ── Users ─────────────────────────────────────────────────────────────────

    suspend fun saveUser(user: User): Result<Unit> = runCatching {
        db.collection("users").document(user.uid).set(user.toMap()).await()
    }

    suspend fun getUser(uid: String): Result<User> = runCatching {
        val snap = db.collection("users").document(uid).get().await()
        snap.toObject(User::class.java) ?: throw Exception("User not found")
    }

    suspend fun getCurrentUser(): Result<User> = getUser(currentUserId)

    suspend fun updateFcmToken(token: String): Result<Unit> = runCatching {
        db.collection("users").document(currentUserId)
            .update("fcmToken", token).await()
    }

    // ── Help Requests ─────────────────────────────────────────────────────────

    suspend fun postRequest(request: HelpRequest): Result<String> = runCatching {
        val ref = db.collection("requests").document()
        val withId = request.copy(id = ref.id)
        ref.set(withId.toMap()).await()
        ref.id
    }

    suspend fun updateRequestStatus(
        requestId: String,
        status: String,
        helperUid: String = "",
        helperName: String = ""
    ): Result<Unit> = runCatching {
        val updates = mutableMapOf<String, Any>("status" to status)
        if (helperUid.isNotEmpty()) updates["helperUid"] = helperUid
        if (helperName.isNotEmpty()) updates["helperName"] = helperName
        db.collection("requests").document(requestId).update(updates).await()
    }

    fun getOpenRequests(): Flow<List<HelpRequest>> = callbackFlow {
        val listener = db.collection("requests")
            .whereEqualTo("status", "open")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull {
                    it.toObject(HelpRequest::class.java)
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun getElderRequests(elderUid: String): Flow<List<HelpRequest>> = callbackFlow {
        val listener = db.collection("requests")
            .whereEqualTo("elderUid", elderUid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull {
                    it.toObject(HelpRequest::class.java)
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun getHelperRequests(helperUid: String): Flow<List<HelpRequest>> = callbackFlow {
        val listener = db.collection("requests")
            .whereEqualTo("helperUid", helperUid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull {
                    it.toObject(HelpRequest::class.java)
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    // ── Medications ───────────────────────────────────────────────────────────

    suspend fun saveMedication(med: Medication): Result<String> = runCatching {
        val ref = if (med.id.isEmpty()) db.collection("medications").document()
                  else db.collection("medications").document(med.id)
        val withId = med.copy(id = ref.id)
        ref.set(withId.toMap()).await()
        ref.id
    }

    suspend fun deleteMedication(medId: String): Result<Unit> = runCatching {
        db.collection("medications").document(medId).delete().await()
    }

    fun getMedicationsForElder(elderUid: String): Flow<List<Medication>> = callbackFlow {
        val listener = db.collection("medications")
            .whereEqualTo("elderUid", elderUid)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                val list = snap?.documents?.mapNotNull {
                    it.toObject(Medication::class.java)
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }
}
