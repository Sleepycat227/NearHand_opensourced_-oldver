package com.nearhand.app.model

import com.google.firebase.Timestamp

data class User(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val role: String = "",
    val phone: String = "",
    val fcmToken: String = "",
    val linkedElderUid: String = ""
) {
    fun toMap(): Map<String, Any> = mapOf(
        "uid" to uid,
        "name" to name,
        "email" to email,
        "role" to role,
        "phone" to phone,
        "fcmToken" to fcmToken,
        "linkedElderUid" to linkedElderUid
    )
}

data class HelpRequest(
    val id: String = "",
    val elderUid: String = "",
    val elderName: String = "",
    val elderPhone: String = "",
    val type: String = "",
    val description: String = "",
    val address: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val status: String = "open",
    val helperUid: String = "",
    val helperName: String = "",
    val createdAt: Timestamp = Timestamp.now()
) {
    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "elderUid" to elderUid,
        "elderName" to elderName,
        "elderPhone" to elderPhone,
        "type" to type,
        "description" to description,
        "address" to address,
        "latitude" to latitude,
        "longitude" to longitude,
        "status" to status,
        "helperUid" to helperUid,
        "helperName" to helperName,
        "createdAt" to createdAt
    )
}

data class Medication(
    val id: String = "",
    val elderUid: String = "",
    val name: String = "",
    val dosage: String = "",
    val instructions: String = "",
    val timeHour: Int = 8,
    val timeMinute: Int = 0,
    val isDaily: Boolean = true,
    val isActive: Boolean = true,
    val setByName: String = "",
    val setByUid: String = ""
) {
    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "elderUid" to elderUid,
        "name" to name,
        "dosage" to dosage,
        "instructions" to instructions,
        "timeHour" to timeHour,
        "timeMinute" to timeMinute,
        "isDaily" to isDaily,
        "isActive" to isActive,
        "setByName" to setByName,
        "setByUid" to setByUid
    )
}

enum class RequestType(val displayName: String, val emoji: String) {
    ERRAND("Run an Errand", "🛒"),
    MASSAGE("Leg Massage", "🦵"),
    HUG("Quick Hug", "🤗"),
    CHAT("Just Chat", "💬"),
    MEDICINE("Help with Medicine", "💊"),
    OTHER("Other", "🙏")
}

enum class UserRole(val value: String) {
    ELDER("elder"),
    HELPER("helper")
}
