package com.nearhand.app.elder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import com.nearhand.app.BaseActivity
import com.nearhand.app.R
import com.nearhand.app.databinding.ActivityAmbulanceConfirmBinding

/**
 * AmbulanceConfirmActivity
 *
 * A dedicated confirmation screen that the user must actively swipe through
 * before a 112 call is placed. The swipe is horizontal (right-to-confirm)
 * which is deliberately different from the vertical swipe in FallAlertActivity,
 * so the two gestures don't clash when the fall alert is also on screen.
 *
 * Interaction design:
 *  • The red thumb starts at the left of the track.
 *  • The user drags it right. It follows the finger in real time.
 *  • If they release before reaching 80 % of the track, the thumb snaps back.
 *  • If they pass 80 %, the call fires immediately — no button press needed.
 *  • The hint label fades out as the thumb travels right, so the moving thumb
 *    becomes the only thing on screen and there is no visual clutter at the
 *    moment of confirmation.
 *  • "Cancel" button returns to the home screen with no call placed.
 *
 * Permission handling:
 *  • If CALL_PHONE is already granted, ACTION_CALL fires immediately — the
 *    system phone app picks up the call without any extra tap.
 *  • If CALL_PHONE is not yet granted, we request it. On grant, the call
 *    fires automatically from the result callback.
 *  • We never fall back to ACTION_DIAL — that would require the user to
 *    manually tap the call button, defeating the purpose of this screen.
 */
class AmbulanceConfirmActivity : BaseActivity() {

    companion object {
        private const val AMBULANCE_NUMBER  = "112"
        /** Fraction of track width that must be covered to confirm the call. */
        private const val CONFIRM_THRESHOLD = 0.80f
    }

    private lateinit var binding: ActivityAmbulanceConfirmBinding

    private var dragStartX = 0f
    private var maxDrag    = 0f
    private var callPlaced = false

    // ── Permission launcher ───────────────────────────────────────────────────

    private val callPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            tryPlaceCall()
        } else {
            // User explicitly denied. Show a one-sentence explanation then dismiss.
            AlertDialog.Builder(this)
                .setTitle(R.string.fall_detected_title) // reuse "Emergency" title
                .setMessage(getString(R.string.call_permission_required_message))
                .setPositiveButton(android.R.string.ok) { _, _ -> finish() }
                .show()
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAmbulanceConfirmBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCancel.setOnClickListener { finish() }
        setupSwipe()
    }

    // ── Swipe logic ───────────────────────────────────────────────────────────

    private fun setupSwipe() {
        binding.swipeTrack.post {
            maxDrag = (binding.swipeTrack.width - binding.swipeThumb.width).toFloat()
        }

        binding.swipeThumb.setOnTouchListener { _, event ->
            when (event.action) {

                MotionEvent.ACTION_DOWN -> {
                    dragStartX = event.rawX - binding.swipeThumb.translationX
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val newX = (event.rawX - dragStartX).coerceIn(0f, maxDrag)
                    binding.swipeThumb.translationX = newX

                    val progress = newX / maxDrag
                    binding.tvSwipeHint.alpha = 1f - progress

                    if (progress >= CONFIRM_THRESHOLD && !callPlaced) {
                        callPlaced = true
                        placeCall()
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!callPlaced) {
                        binding.swipeThumb.animate().translationX(0f).setDuration(250).start()
                        binding.tvSwipeHint.animate().alpha(0.7f).setDuration(250).start()
                    }
                    true
                }

                else -> false
            }
        }
    }

    // ── Call placement ────────────────────────────────────────────────────────

    private val roleRequestLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            // Role granted — now placeCall() will go directly to telephony
            dialViaTelecom()
        } else {
            // User declined the role prompt — fall back to ACTION_CALL
            // which is still better than the dialer on most non-Xiaomi devices
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$AMBULANCE_NUMBER")))
            finish()
        }
    }

    private fun placeCall() {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE)
            == PackageManager.PERMISSION_GRANTED
        ) {
            tryPlaceCall()
        } else {
            callPermissionLauncher.launch(Manifest.permission.CALL_PHONE)
        }
    }

    private fun tryPlaceCall() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(android.app.role.RoleManager::class.java)
            if (roleManager.isRoleHeld(android.app.role.RoleManager.ROLE_DIALER)) {
                // Already the default dialer — call straight through
                dialViaTelecom()
            } else {
                // Ask to become default dialer, then call in the result callback
                val intent = roleManager.createRequestRoleIntent(
                    android.app.role.RoleManager.ROLE_DIALER
                )
                roleRequestLauncher.launch(intent)
            }
        } else {
            // API < 29: RoleManager unavailable, use ACTION_CALL directly
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$AMBULANCE_NUMBER")))
            finish()
        }
    }

    private fun dialViaTelecom() {
        val uri = Uri.parse("tel:$AMBULANCE_NUMBER")
        val telecom = getSystemService(TELECOM_SERVICE) as android.telecom.TelecomManager
        val extras = android.os.Bundle().apply {
            putBoolean(android.telecom.TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, false)
        }
        try {
            telecom.placeCall(uri, extras)
        } catch (e: SecurityException) {
            startActivity(Intent(Intent.ACTION_CALL, uri))
        }
        finish()
    }
}
