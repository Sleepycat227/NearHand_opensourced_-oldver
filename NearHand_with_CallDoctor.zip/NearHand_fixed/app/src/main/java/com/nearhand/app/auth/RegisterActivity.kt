package com.nearhand.app.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.nearhand.app.BaseActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import com.nearhand.app.databinding.ActivityRegisterBinding
import com.nearhand.app.elder.ElderHomeActivity
import com.nearhand.app.helper.HelperHomeActivity
import com.nearhand.app.model.User
import com.nearhand.app.model.UserRole
import com.nearhand.app.utils.FirebaseRepository
import kotlinx.coroutines.launch

class RegisterActivity : BaseActivity() {

    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnRegister.setOnClickListener { attemptRegister() }
        binding.tvGoLogin.setOnClickListener { finish() }
    }

    private fun attemptRegister() {
        val name     = binding.etName.text.toString().trim()
        val email    = binding.etEmail.text.toString().trim()
        val phone    = binding.etPhone.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        val confirm  = binding.etConfirmPassword.text.toString().trim()
        val role     = if (binding.rbElder.isChecked) UserRole.ELDER.value else UserRole.HELPER.value

        if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty()) {
            showSnack("Please fill in all fields"); return
        }
        if (password != confirm) { showSnack("Passwords do not match"); return }
        if (password.length < 6) { showSnack("Password must be at least 6 characters"); return }

        setLoading(true)
        lifecycleScope.launch {
            FirebaseRepository.register(email, password)
                .onSuccess { uid ->
                    val user = User(uid = uid, name = name, email = email, role = role, phone = phone)
                    FirebaseRepository.saveUser(user)
                        .onSuccess {
                            setLoading(false)
                            val dest = if (role == UserRole.ELDER.value) ElderHomeActivity::class.java
                                       else HelperHomeActivity::class.java
                            startActivity(Intent(this@RegisterActivity, dest))
                            finishAffinity()
                        }
                        .onFailure { e -> showSnack(e.message ?: "Profile save failed"); setLoading(false) }
                }
                .onFailure { e -> showSnack(e.message ?: "Registration failed"); setLoading(false) }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.btnRegister.isEnabled = !loading
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun showSnack(msg: String) = Snackbar.make(binding.root, msg, Snackbar.LENGTH_LONG).show()
}
