package com.nearhand.app.fall

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences

/**
 * Restarts fall detection monitoring after the device reboots.
 *
 * Android stops all services and clears notifications on reboot, so without
 * this receiver an elder whose phone restarts (e.g. after an update) would
 * have NO fall protection until they manually reopen the app.
 *
 * We only restart monitoring if it was previously active, tracked via the
 * "fall_detection_enabled" flag which ElderHomeActivity sets when starting
 * the service and SettingsActivity / logout clears when stopping it.
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        const val PREFS_NAME = "nearhand_prefs"
        const val KEY_FALL_DETECTION_ENABLED = "fall_detection_enabled"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON" ||
            intent.action == "android.intent.action.LOCKED_BOOT_COMPLETED"
        ) {
            val prefs: SharedPreferences =
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val wasEnabled = prefs.getBoolean(KEY_FALL_DETECTION_ENABLED, false)
            if (wasEnabled) {
                FallDetectionService.startService(context)
            }
        }
    }
}
