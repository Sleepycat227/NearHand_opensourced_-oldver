package com.nearhand.app.doctor

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.nearhand.app.BaseActivity
import com.nearhand.app.R
import com.nearhand.app.databinding.ActivityDoctorSetupBinding

/**
 * DoctorSetupActivity
 *
 * Shown the very first time the user taps "Call Your Doctor" — or whenever
 * they tap the pencil/edit icon in CallDoctorActivity to change the saved
 * contact.  The screen is intentionally designed for a *trusted person*
 * (family member, caregiver) to fill in rather than the elder themselves,
 * hence the large explanatory banner at the top.
 *
 * Data is persisted to SharedPreferences so it survives app restarts without
 * any server round-trip.  Fields:
 *   • doctor_name   – display name shown on the call screen
 *   • doctor_phone  – E.164 or local number dialed directly
 *
 * The activity finishes with RESULT_OK after saving so the caller
 * (CallDoctorActivity) can refresh its UI immediately.
 */
class DoctorSetupActivity : BaseActivity() {

    private lateinit var binding: ActivityDoctorSetupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDoctorSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Pre-fill if we are *editing* an existing contact
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        binding.etDoctorName.setText(prefs.getString(KEY_NAME, ""))
        binding.etDoctorPhone.setText(prefs.getString(KEY_PHONE, ""))

        binding.btnBack.setOnClickListener { finish() }

        binding.btnSaveDoctor.setOnClickListener {
            val name  = binding.etDoctorName.text.toString().trim()
            val phone = binding.etDoctorPhone.text.toString().trim()

            if (name.isEmpty()) {
                binding.etDoctorName.error = getString(R.string.doctor_name_required)
                return@setOnClickListener
            }
            if (phone.isEmpty()) {
                binding.etDoctorPhone.error = getString(R.string.doctor_phone_required)
                return@setOnClickListener
            }

            prefs.edit()
                .putString(KEY_NAME, name)
                .putString(KEY_PHONE, phone)
                .apply()

            Toast.makeText(this, getString(R.string.doctor_saved), Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK)
            finish()
        }
    }

    companion object {
        const val PREFS     = "doctor_prefs"
        const val KEY_NAME  = "doctor_name"
        const val KEY_PHONE = "doctor_phone"

        /** Convenience launcher. */
        fun start(context: Context) =
            context.startActivity(Intent(context, DoctorSetupActivity::class.java))
    }
}
