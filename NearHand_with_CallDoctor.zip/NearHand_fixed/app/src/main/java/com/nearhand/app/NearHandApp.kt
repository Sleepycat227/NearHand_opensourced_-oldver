package com.nearhand.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.nearhand.app.fall.BootReceiver
import com.nearhand.app.fall.FallDetectionWatchdog
import com.nearhand.app.fall.FallDetectionService
import com.nearhand.app.utils.LanguageUtils
import timber.log.Timber

class NearHandApp : Application() {

    companion object {
        const val CHANNEL_MEDICATION = "nearhand_medication"
        const val CHANNEL_REQUESTS   = "nearhand_requests"
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(LanguageUtils.wrap(base))
    }

    override fun onCreate() {
        super.onCreate()
        Timber.plant(Timber.DebugTree())
        createNotificationChannels()

        // Schedule the periodic watchdog that restarts FallDetectionService
        // if the OS kills it. KEEP policy means we never disturb an existing schedule.
        FallDetectionWatchdog.schedule(this)

        // If fall detection was active before the process was killed, restart it now.
        // Wrapped in try/catch because on Android 12+ (API 31+) startForegroundService()
        // throws ForegroundServiceStartNotAllowedException when the app is started from the
        // background (WorkManager job, boot receiver, FCM push, etc.) and the OS has not yet
        // granted a foreground-service start token.  In those cases we silently skip the
        // restart here — the FallDetectionWatchdog PeriodicWorkRequest will retry within 15
        // minutes, by which time the app will have been foregrounded and the restriction lifted.
        val prefs = getSharedPreferences(BootReceiver.PREFS_NAME, MODE_PRIVATE)
        if (prefs.getBoolean(BootReceiver.KEY_FALL_DETECTION_ENABLED, false) &&
            !FallDetectionService.isRunning
        ) {
            try {
                FallDetectionService.startService(this)
            } catch (e: Exception) {
                // ForegroundServiceStartNotAllowedException (API 31+) or SecurityException —
                // background start was blocked by the OS.  The watchdog will retry.
                Timber.w(e, "Could not start FallDetectionService from Application.onCreate() " +
                        "(background start restriction). Watchdog will retry.")
            }
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            val medChannel = NotificationChannel(
                CHANNEL_MEDICATION,
                "Medication Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Reminders to take your medication on time"
                enableVibration(true)
            }

            val reqChannel = NotificationChannel(
                CHANNEL_REQUESTS,
                "Help Requests",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for new help requests"
            }

            manager.createNotificationChannel(medChannel)
            manager.createNotificationChannel(reqChannel)
        }
    }
}
