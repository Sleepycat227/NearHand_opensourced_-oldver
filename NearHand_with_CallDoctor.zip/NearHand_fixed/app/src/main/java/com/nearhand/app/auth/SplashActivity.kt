package com.nearhand.app.auth

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.nearhand.app.BaseActivity
import androidx.lifecycle.lifecycleScope
import com.nearhand.app.elder.ElderHomeActivity
import com.nearhand.app.helper.HelperHomeActivity
import com.nearhand.app.model.UserRole
import com.nearhand.app.utils.FirebaseRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@SuppressLint("CustomSplashScreen")
class SplashActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lifecycleScope.launch {
            delay(1500) // Show splash for 1.5s

            if (!FirebaseRepository.isLoggedIn) {
                startActivity(Intent(this@SplashActivity, LoginActivity::class.java))
                finish()
                return@launch
            }

            // Already logged in — route by role
            val result = FirebaseRepository.getCurrentUser()
            result.onSuccess { user ->
                val dest = if (user.role == UserRole.ELDER.value) ElderHomeActivity::class.java
                           else HelperHomeActivity::class.java
                startActivity(Intent(this@SplashActivity, dest))
                finish()
            }.onFailure {
                // Something went wrong, send to login
                startActivity(Intent(this@SplashActivity, LoginActivity::class.java))
                finish()
            }
        }
    }
}
