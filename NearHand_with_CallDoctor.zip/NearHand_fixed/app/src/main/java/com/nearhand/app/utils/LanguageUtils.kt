package com.nearhand.app.utils

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import java.util.Locale

object LanguageUtils {

    private const val PREF_NAME = "nearhand_prefs"
    private const val KEY_LANGUAGE = "selected_language"

    data class Language(
        val code: String,
        val displayName: String,
        val nativeName: String
    )

    val supportedLanguages = listOf(
        Language("en", "English", "English"),
        Language("hi", "Hindi", "हिन्दी"),
        Language("bn", "Bengali", "বাংলা"),
        Language("ta", "Tamil", "தமிழ்"),
        Language("te", "Telugu", "తెలుగు"),
        Language("kn", "Kannada", "ಕನ್ನಡ"),
        Language("ml", "Malayalam", "മലയാളം"),
        Language("mr", "Marathi", "मराठी"),
        Language("gu", "Gujarati", "ગુજરાતી"),
        Language("pa", "Punjabi", "ਪੰਜਾਬੀ"),
        Language("or", "Odia", "ଓଡ଼ିଆ"),
        Language("ur", "Urdu", "اردو")
    )

    fun getSavedLanguageCode(context: Context): String {
        return getPrefs(context).getString(KEY_LANGUAGE, "en") ?: "en"
    }

    fun saveLanguageCode(context: Context, code: String) {
        getPrefs(context).edit().putString(KEY_LANGUAGE, code).apply()
    }

    fun applyLanguage(context: Context, code: String): Context {
        val locale = Locale(code)
        Locale.setDefault(locale)
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        return context.createConfigurationContext(config)
    }

    fun wrap(context: Context): Context {
        val code = getSavedLanguageCode(context)
        return applyLanguage(context, code)
    }

    private fun getPrefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
}
