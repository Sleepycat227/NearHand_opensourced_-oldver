package com.nearhand.app.medication

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nearhand.app.databinding.ItemMedicationBinding
import com.nearhand.app.model.Medication

class MedicationAdapter(
    private val onDelete: (Medication) -> Unit
) : ListAdapter<Medication, MedicationAdapter.ViewHolder>(DIFF) {

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Medication>() {
            override fun areItemsTheSame(a: Medication, b: Medication) = a.id == b.id
            override fun areContentsTheSame(a: Medication, b: Medication) = a == b
        }
    }

    inner class ViewHolder(val binding: ItemMedicationBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemMedicationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val med = getItem(position)
        val b   = holder.binding

        b.tvMedName.text    = med.name
        b.tvDosage.text     = med.dosage.ifEmpty { "Dosage not specified" }
        b.tvInstructions.text = med.instructions.ifEmpty { "" }

        val hour   = if (med.timeHour == 0) 12 else if (med.timeHour > 12) med.timeHour - 12 else med.timeHour
        val minute = String.format("%02d", med.timeMinute)
        val amPm   = if (med.timeHour < 12) "AM" else "PM"
        b.tvTime.text = "$hour:$minute $amPm"

        b.tvFrequency.text = if (med.isDaily) "Daily" else "One-time"
        b.tvSetBy.text     = "Set by ${med.setByName}"

        b.btnDelete.setOnClickListener { onDelete(med) }
    }
}
