package com.nearhand.app.elder

import android.Manifest
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.nearhand.app.BaseActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.snackbar.Snackbar
import com.nearhand.app.databinding.ActivityPostRequestBinding
import com.nearhand.app.model.HelpRequest
import com.nearhand.app.model.RequestType
import com.nearhand.app.utils.FirebaseRepository
import kotlinx.coroutines.launch
import java.util.Locale

class PostRequestActivity : BaseActivity() {

    private lateinit var binding: ActivityPostRequestBinding
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val requestTypes = RequestType.values()
    private var detectedLat = 0.0
    private var detectedLng = 0.0

    companion object {
        private const val LOCATION_PERMISSION_REQUEST = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPostRequestBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        val typeLabels = requestTypes.map { "${it.emoji}  ${it.displayName}" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, typeLabels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerType.adapter = adapter

        binding.btnDetectLocation.setOnClickListener { detectLocation() }
        binding.btnPost.setOnClickListener { postRequest() }
    }

    private fun detectLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                LOCATION_PERMISSION_REQUEST
            )
            return
        }
        binding.btnDetectLocation.isEnabled = false
        binding.btnDetectLocation.text = "Detecting..."
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            binding.btnDetectLocation.isEnabled = true
            binding.btnDetectLocation.text = "📍 Detect My Location"
            if (location != null) {
                detectedLat = location.latitude
                detectedLng = location.longitude
                try {
                    val geocoder = Geocoder(this, Locale.getDefault())
                    val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                    if (!addresses.isNullOrEmpty()) {
                        val addr = addresses[0]
                        val readable = buildString {
                            if (!addr.subLocality.isNullOrEmpty()) append("${addr.subLocality}, ")
                            if (!addr.locality.isNullOrEmpty()) append("${addr.locality}, ")
                            if (!addr.adminArea.isNullOrEmpty()) append(addr.adminArea)
                        }
                        binding.etAddress.setText(readable)
                    }
                } catch (e: Exception) {
                    binding.etAddress.setText("${location.latitude}, ${location.longitude}")
                }
            } else {
                Snackbar.make(binding.root, "Could not detect location. Please enter manually.", Snackbar.LENGTH_LONG).show()
            }
        }.addOnFailureListener {
            binding.btnDetectLocation.isEnabled = true
            binding.btnDetectLocation.text = "📍 Detect My Location"
            Snackbar.make(binding.root, "Location failed. Enter address manually.", Snackbar.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST && grantResults.isNotEmpty()
            && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            detectLocation()
        }
    }

    private fun postRequest() {
        val typeIndex   = binding.spinnerType.selectedItemPosition
        val description = binding.etDescription.text.toString().trim()
        val address     = binding.etAddress.text.toString().trim()
        val selectedType = requestTypes[typeIndex]

        setLoading(true)
        lifecycleScope.launch {
            FirebaseRepository.getCurrentUser()
                .onSuccess { user ->
                    val request = HelpRequest(
                        elderUid    = user.uid,
                        elderName   = user.name,
                        elderPhone  = user.phone,
                        type        = selectedType.name,
                        description = description,
                        address     = address,
                        latitude    = detectedLat,
                        longitude   = detectedLng
                    )
                    FirebaseRepository.postRequest(request)
                        .onSuccess {
                            setLoading(false)
                            Snackbar.make(binding.root, "Request posted! Help is on the way 💛", Snackbar.LENGTH_SHORT).show()
                            binding.etDescription.text?.clear()
                            binding.etAddress.text?.clear()
                            detectedLat = 0.0; detectedLng = 0.0
                        }
                        .onFailure { e -> setLoading(false)
                            Snackbar.make(binding.root, e.message ?: "Failed to post", Snackbar.LENGTH_LONG).show()
                        }
                }
                .onFailure { setLoading(false) }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.btnPost.isEnabled = !loading
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}
