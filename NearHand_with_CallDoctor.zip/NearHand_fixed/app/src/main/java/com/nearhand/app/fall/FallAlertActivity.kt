package com.nearhand.app.fall

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AnimationUtils
import androidx.core.app.ActivityCompat
import com.nearhand.app.BaseActivity
import com.nearhand.app.R
import com.nearhand.app.databinding.ActivityFallAlertBinding
import com.nearhand.app.utils.FirebaseRepository
import com.nearhand.app.utils.LanguageUtils
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

/**
 * FallAlertActivity  (v2)
 *
 * Changes from v1:
 *  • Shown over lock screen AND over other apps via full-screen notification intent
 *    (service posts the notification; activity just needs the window flags).
 *  • placeCall() no longer opens the system dialler — it uses ACTION_CALL directly
 *    so the call starts immediately, just like the Apple Watch behaviour.
 *  • Calls TWO numbers in sequence:
 *      1. The user's stored emergency contact (SharedPreferences "emergency_contact")
 *      2. Indian ambulance: 112  (fallback if no contact saved)
 *  • Temperature events show a different subtitle ("Abrupt temperature change detected").
 *  • EXTRA_IS_TEMP_EVENT boolean from FallDetectionService selects the right message.
 */
class FallAlertActivity : BaseActivity() {

    companion object {
        const val EXTRA_IS_TEMP_EVENT = "is_temp_event"
        private const val PREFS_NAME  = "nearhand_prefs"
        private const val KEY_EMERGENCY_CONTACT = "emergency_contact"
        private const val INDIA_AMBULANCE = "112"
    }

    private lateinit var binding: ActivityFallAlertBinding
    private var countdownTimer: CountDownTimer? = null

    private var swipeStartY = 0f
    private val SWIPE_UP_THRESHOLD = 150f

    private var isTempEvent = false

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over the lock screen on all API levels
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON  or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
        // Appear over any running app (needed for heads-up path)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        isTempEvent = intent.getBooleanExtra(EXTRA_IS_TEMP_EVENT, false)

        binding = ActivityFallAlertBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Hide system UI bars so the alert occupies the entire display.
        // MUST be called AFTER setContentView — window.insetsController delegates to
        // DecorView.getWindowInsetsController(), which returns null (and crashes) until
        // the DecorView is attached, which only happens once setContentView() runs.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.insetsController?.hide(
                android.view.WindowInsets.Type.statusBars() or
                android.view.WindowInsets.Type.navigationBars()
            )
            window.insetsController?.systemBarsBehavior =
                android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        }

        // If it's a temperature event, update the subtitle text
        if (isTempEvent) {
            binding.tvSubtitle.text = getString(R.string.temp_event_subtitle)
        }

        val pulse = AnimationUtils.loadAnimation(this, R.anim.pulse)
        binding.layoutSosSwipe.startAnimation(pulse)

        setupSwipeToCall()
        setupDismissButton()
        startCountdown()
    }

    override fun onDestroy() {
        countdownTimer?.cancel()
        super.onDestroy()
    }

    // ── Countdown (30 s → auto-call) ──────────────────────────────────────────
    private fun startCountdown() {
        val totalSeconds = 30
        binding.tvCountdown.visibility = View.VISIBLE
        binding.progressCountdown.max = totalSeconds

        countdownTimer = object : CountDownTimer(totalSeconds * 1000L, 1_000L) {
            override fun onTick(millisUntilFinished: Long) {
                val secs = (millisUntilFinished / 1000).toInt()
                binding.tvCountdown.text = secs.toString()
                binding.progressCountdown.progress = secs
                if (secs <= 5) {
                    binding.tvCountdown.setTextColor(getColor(R.color.error))
                }
            }
            override fun onFinish() {
                binding.progressCountdown.progress = 0
                placeCall()
            }
        }.start()
    }

    // ── Swipe-up to call ──────────────────────────────────────────────────────
    private fun setupSwipeToCall() {
        binding.layoutSosSwipe.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { swipeStartY = event.y; true }
                MotionEvent.ACTION_UP   -> {
                    val deltaY = swipeStartY - event.y
                    if (deltaY > SWIPE_UP_THRESHOLD) {
                        countdownTimer?.cancel()
                        placeCall()
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ── Dismiss ───────────────────────────────────────────────────────────────
    private fun setupDismissButton() {
        binding.btnImOk.setOnClickListener {
            countdownTimer?.cancel()
            finish()
        }
    }

    // ── Place the call ────────────────────────────────────────────────────────
    /**
     * Call order:
     *  1. User's saved emergency contact — placed with TelecomManager.placeCall().
     *  2. India ambulance 112 — placed with ACTION_CALL_EMERGENCY.
     *
     * Why two different strategies:
     *
     *  Personal contact (non-emergency number):
     *    TelecomManager.placeCall() bypasses the dialler UI and calls immediately,
     *    as long as CALL_PHONE is granted. ACTION_CALL is used as a fallback.
     *
     *  112 (emergency number):
     *    Samsung's Telecom stack (and stock Android) explicitly REJECTS ACTION_CALL for
     *    recognised emergency numbers unless the caller is the system or default dialler —
     *    confirmed in logcat: "Cannot call potential emergency number 112 with CALL Intent
     *    unless caller is system or default dialer." That is why the dialler was opening.
     *    ACTION_CALL_EMERGENCY is whitelisted by the OS for ALL apps, requires no
     *    CALL_PHONE permission, and bypasses the default-dialler restriction entirely.
     */
    private fun placeCall() {
        val emergencyContact = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_EMERGENCY_CONTACT, null)
            ?.takeIf { it.isNotBlank() }

        if (emergencyContact != null) {
            // Path 1: personal emergency contact (non-emergency number)
            val uri = Uri.parse("tel:$emergencyContact")
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                == PackageManager.PERMISSION_GRANTED
            ) {
                val telecom = getSystemService(TELECOM_SERVICE) as android.telecom.TelecomManager
                val extras = android.os.Bundle().apply {
                    putBoolean(android.telecom.TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, false)
                }
                try {
                    telecom.placeCall(uri, extras)
                } catch (e: SecurityException) {
                    startActivity(Intent(Intent.ACTION_CALL, uri))
                }
            } else {
                startActivity(Intent(Intent.ACTION_DIAL, uri))
            }
        } else {
            // Path 2: no contact saved — call Indian ambulance 112.
            // ACTION_CALL_EMERGENCY is whitelisted by Android/Samsung Telecom for all apps;
            // it requires no CALL_PHONE permission and bypasses the default-dialler check.
            val uri = Uri.parse("tel:$INDIA_AMBULANCE")
            startActivity(Intent("android.intent.action.CALL_EMERGENCY", uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        }
        finish()
    }

    override fun onBackPressed() {
        countdownTimer?.cancel()
        super.onBackPressed()
    }
}
