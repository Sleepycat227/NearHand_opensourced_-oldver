package com.nearhand.app.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.nearhand.app.BaseActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import com.nearhand.app.databinding.ActivityLoginBinding
import com.nearhand.app.elder.ElderHomeActivity
import com.nearhand.app.helper.HelperHomeActivity
import com.nearhand.app.model.UserRole
import com.nearhand.app.utils.FirebaseRepository
import kotlinx.coroutines.launch

class LoginActivity : BaseActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener { attemptLogin() }
        binding.tvGoRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun attemptLogin() {
        val email    = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        if (email.isEmpty() || password.isEmpty()) {
            showSnack("Please fill in all fields")
            return
        }

        setLoading(true)
        lifecycleScope.launch {
            FirebaseRepository.login(email, password)
                .onSuccess {
                    FirebaseRepository.getCurrentUser()
                        .onSuccess { user ->
                            setLoading(false)
                            val dest = if (user.role == UserRole.ELDER.value) ElderHomeActivity::class.java
                                       else HelperHomeActivity::class.java
                            startActivity(Intent(this@LoginActivity, dest))
                            finishAffinity()
                        }
                        .onFailure { showSnack("Could not fetch user data"); setLoading(false) }
                }
                .onFailure { e -> showSnack(e.message ?: "Login failed"); setLoading(false) }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.btnLogin.isEnabled = !loading
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun showSnack(msg: String) =
        Snackbar.make(binding.root, msg, Snackbar.LENGTH_LONG).show()
}
