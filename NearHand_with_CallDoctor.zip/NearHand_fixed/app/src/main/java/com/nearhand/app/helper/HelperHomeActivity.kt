package com.nearhand.app.helper

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.nearhand.app.BaseActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.nearhand.app.R
import com.nearhand.app.auth.LoginActivity
import com.nearhand.app.databinding.ActivityHelperHomeBinding
import com.nearhand.app.medication.MedicationListActivity
import com.nearhand.app.settings.SettingsActivity
import com.nearhand.app.utils.FirebaseRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class HelperHomeActivity : BaseActivity() {

    private lateinit var binding: ActivityHelperHomeBinding
    private lateinit var adapter: RequestsAdapter
    private var feedJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHelperHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // Defensively dismiss any system-provided action bar before installing our Toolbar.
        // If the activity is ever launched under a theme that still has windowActionBar=true
        // (e.g. a misconfigured intent or a test runner), calling setSupportActionBar() on
        // top of it throws IllegalStateException: "This Activity already has an action bar
        // supplied by the window decor." Hiding it first makes the call safe in all cases.
        supportActionBar?.hide()
        setSupportActionBar(binding.toolbar)

        adapter = RequestsAdapter(isHelperView = true) { request ->
            val intent = Intent(this, RequestDetailActivity::class.java).apply {
                putExtra("requestId",   request.id)
                putExtra("elderName",   request.elderName)
                putExtra("elderPhone",  request.elderPhone)
                putExtra("type",        request.type)
                putExtra("description", request.description)
                putExtra("status",      request.status)
                putExtra("address",     request.address)
                putExtra("helperUid",   request.helperUid)
            }
            startActivity(intent)
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                when (tab.position) { 0 -> loadOpenRequests(); 1 -> loadMyAccepted() }
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        loadOpenRequests()

        binding.fabMedications.setOnClickListener {
            startActivity(Intent(this, MedicationListActivity::class.java))
        }
    }

    private fun loadOpenRequests() {
        feedJob?.cancel()
        feedJob = lifecycleScope.launch {
            FirebaseRepository.getOpenRequests().collectLatest { requests ->
                adapter.submitList(requests)
                binding.tvEmpty.visibility = if (requests.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun loadMyAccepted() {
        feedJob?.cancel()
        feedJob = lifecycleScope.launch {
            FirebaseRepository.getHelperRequests(FirebaseRepository.currentUserId).collectLatest { requests ->
                adapter.submitList(requests)
                binding.tvEmpty.visibility = if (requests.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_home, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> { startActivity(Intent(this, SettingsActivity::class.java)); true }
            R.id.action_logout -> {
                FirebaseRepository.logout()
                startActivity(Intent(this, LoginActivity::class.java))
                finishAffinity(); true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
