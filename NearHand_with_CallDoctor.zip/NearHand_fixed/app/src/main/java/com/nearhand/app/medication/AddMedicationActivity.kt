package com.nearhand.app.medication

import android.os.Bundle
import android.view.View
import android.widget.TimePicker
import androidx.appcompat.app.AppCompatActivity
import com.nearhand.app.BaseActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import com.nearhand.app.databinding.ActivityAddMedicationBinding
import com.nearhand.app.model.Medication
import com.nearhand.app.utils.FirebaseRepository
import kotlinx.coroutines.launch

class AddMedicationActivity : BaseActivity() {

    private lateinit var binding: ActivityAddMedicationBinding

    // The elder UID this medication is for — defaults to current user
    // (a helper can set this for a linked elder)
    private var targetElderUid = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddMedicationBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.timePicker.setIs24HourView(false)

        lifecycleScope.launch {
            FirebaseRepository.getCurrentUser()
                .onSuccess { user ->
                    targetElderUid = if (user.role == "elder") user.uid
                                     else user.linkedElderUid
                }
        }

        binding.btnSave.setOnClickListener { saveMedication() }
    }

    private fun saveMedication() {
        val name         = binding.etMedName.text.toString().trim()
        val dosage       = binding.etDosage.text.toString().trim()
        val instructions = binding.etInstructions.text.toString().trim()
        val isDaily      = binding.switchDaily.isChecked
        val hour         = binding.timePicker.hour
        val minute       = binding.timePicker.minute

        if (name.isEmpty()) { showSnack("Please enter the medication name"); return }
        if (targetElderUid.isEmpty()) { showSnack("No elder linked to this account"); return }

        setLoading(true)
        lifecycleScope.launch {
            FirebaseRepository.getCurrentUser().onSuccess { currentUser ->
                val med = Medication(
                    elderUid     = targetElderUid,
                    name         = name,
                    dosage       = dosage,
                    instructions = instructions,
                    timeHour     = hour,
                    timeMinute   = minute,
                    isDaily      = isDaily,
                    setByName    = currentUser.name,
                    setByUid     = currentUser.uid
                )
                FirebaseRepository.saveMedication(med)
                    .onSuccess { savedId ->
                        val savedMed = med.copy(id = savedId)
                        MedicationAlarmScheduler.schedule(this@AddMedicationActivity, savedMed)
                        setLoading(false)
                        showSnack("Medication reminder set! ⏰")
                        finish()
                    }
                    .onFailure { e ->
                        setLoading(false)
                        showSnack(e.message ?: "Failed to save medication")
                    }
            }.onFailure { setLoading(false) }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.btnSave.isEnabled  = !loading
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun showSnack(msg: String) =
        Snackbar.make(binding.root, msg, Snackbar.LENGTH_LONG).show()

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}
