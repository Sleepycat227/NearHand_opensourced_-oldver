package com.nearhand.app.medication

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.nearhand.app.BaseActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nearhand.app.databinding.ActivityMedicationListBinding
import com.nearhand.app.utils.FirebaseRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MedicationListActivity : BaseActivity() {

    private lateinit var binding: ActivityMedicationListBinding
    private lateinit var adapter: MedicationAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMedicationListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        adapter = MedicationAdapter(
            onDelete = { med ->
                MedicationAlarmScheduler.cancel(this, med)
                lifecycleScope.launch { FirebaseRepository.deleteMedication(med.id) }
            }
        )

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, AddMedicationActivity::class.java))
        }

        loadMedications()
    }

    private fun loadMedications() {
        lifecycleScope.launch {
            val uid = FirebaseRepository.currentUserId
            FirebaseRepository.getMedicationsForElder(uid).collectLatest { meds ->
                adapter.submitList(meds)
                binding.tvEmpty.visibility = if (meds.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}
