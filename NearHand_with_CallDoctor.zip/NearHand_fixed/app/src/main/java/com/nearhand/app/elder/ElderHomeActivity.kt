package com.nearhand.app.elder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.nearhand.app.BaseActivity
import com.nearhand.app.R
import com.nearhand.app.auth.LoginActivity
import com.nearhand.app.databinding.ActivityElderHomeBinding
import com.nearhand.app.fall.FallDetectionService
import com.nearhand.app.fall.FallDetectionWatchdog
import com.nearhand.app.elder.AmbulanceConfirmActivity
import com.nearhand.app.medication.MedicationListActivity
import com.nearhand.app.settings.SettingsActivity
import com.nearhand.app.utils.FirebaseRepository
import com.nearhand.app.doctor.CallDoctorActivity

class ElderHomeActivity : BaseActivity() {

    private lateinit var binding: ActivityElderHomeBinding

    companion object {
        private const val PERMISSIONS_REQUEST_CODE = 2001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityElderHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        binding.cardPostRequest.setOnClickListener { startActivity(Intent(this, PostRequestActivity::class.java)) }
        binding.cardMyRequests.setOnClickListener  { startActivity(Intent(this, MyRequestsActivity::class.java)) }
        binding.cardMedications.setOnClickListener { startActivity(Intent(this, MedicationListActivity::class.java)) }
        binding.cardAmbulance.setOnClickListener   { startActivity(Intent(this, AmbulanceConfirmActivity::class.java)) }
        binding.cardCallDoctor.setOnClickListener  { startActivity(Intent(this, CallDoctorActivity::class.java)) }

        // Request the permissions fall detection actually depends on, then
        // start the background monitoring service.
        ensureFallDetectionPermissions()
    }

    /**
     * Fall detection needs several permissions to truly work in the background
     * and to auto-dial without user interaction:
     *  • CALL_PHONE        – place the emergency call automatically (no dialer tap)
     *  • POST_NOTIFICATIONS – show the full-screen alert / foreground service notice
     *  • ACTIVITY_RECOGNITION / BODY_SENSORS – read motion sensors in background
     * We also nudge the user to disable battery optimization for the app and to
     * grant "Display over other apps" / full-screen notification access, since
     * OEMs frequently kill background services or block full-screen alerts
     * otherwise.
     */
    private fun ensureFallDetectionPermissions() {
        val needed = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.CALL_PHONE)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.ACTIVITY_RECOGNITION)
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.BODY_SENSORS)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS_BACKGROUND)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.BODY_SENSORS_BACKGROUND)
        }

        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), PERMISSIONS_REQUEST_CODE)
        } else {
            startFallDetectionAndPromptBatteryWhitelist()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            val callDenied = permissions.zip(grantResults.toTypedArray()).any {
                it.first == Manifest.permission.CALL_PHONE && it.second != PackageManager.PERMISSION_GRANTED
            }
            if (callDenied) {
                AlertDialog.Builder(this)
                    .setTitle(R.string.fall_detected_title)
                    .setMessage(getString(R.string.call_permission_required_message))
                    .setPositiveButton(android.R.string.ok, null)
                    .show()
            }
            startFallDetectionAndPromptBatteryWhitelist()
        }
    }

    /**
     * Starts the always-on fall detection service and, on the first run,
     * asks the user to exempt NearHand from battery optimization. Without
     * this exemption many OEMs (Xiaomi, Samsung, OnePlus, etc.) silently kill
     * the background service within minutes of the screen turning off.
     */
    private fun startFallDetectionAndPromptBatteryWhitelist() {
        FallDetectionService.startService(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    // Some OEMs disallow this intent; ignore silently.
                }
            }
        }
    }

    override fun onDestroy() {
        // Keep the service running in the background even when activity is closed.
        // It will be stopped only on logout.
        super.onDestroy()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_home, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> { startActivity(Intent(this, SettingsActivity::class.java)); true }
            R.id.action_logout -> {
                FallDetectionService.stopService(this)
                FallDetectionWatchdog.cancel(this)
                FirebaseRepository.logout()
                startActivity(Intent(this, LoginActivity::class.java))
                finishAffinity(); true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
