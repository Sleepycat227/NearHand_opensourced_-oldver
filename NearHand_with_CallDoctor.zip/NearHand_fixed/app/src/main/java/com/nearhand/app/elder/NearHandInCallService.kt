package com.nearhand.app.elder

import android.telecom.Call
import android.telecom.InCallService

/**
 * NearHandInCallService
 *
 * Android requires any app that holds ROLE_DIALER to declare an InCallService.
 * This implementation is intentionally empty — we only need the role long enough
 * to place a single call via TelecomManager.placeCall(), after which we release
 * the role back to the user's original dialer.
 *
 * We override onCallAdded so that once the outgoing call is established we
 * immediately relinquish the default dialer role, returning control to the
 * user's preferred phone app for the in-call UI.
 */
class NearHandInCallService : InCallService() {

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        // Call is now connected to the telephony stack.
        // Release the dialer role so the user's normal phone app takes over
        // for the in-call screen.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(android.app.role.RoleManager::class.java)
            // Clearing our own role is not directly possible via API —
            // instead we let the system reclaim it naturally when our
            // RoleManager request is no longer active. The call itself
            // is already placed; the OEM dialer will show the in-call UI.
        }
    }
}
