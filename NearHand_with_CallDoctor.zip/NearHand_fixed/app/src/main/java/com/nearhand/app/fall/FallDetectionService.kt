package com.nearhand.app.fall

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.nearhand.app.R
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * FallDetectionService  (v2)
 *
 * Changes from v1:
 *  • Thresholds raised significantly to reduce false positives from minor jerks.
 *  • Temperature sensor monitoring: detects abrupt skin-temperature drops
 *    (≥ TEMP_DROP_THRESHOLD °C in TEMP_WINDOW_MS) and can independently trigger
 *    FallAlertActivity.
 *  • Uses a full-screen notification intent so the alert appears over all apps
 *    AND on the lock screen (Android 10+ requires this for foreground services
 *    to interrupt the user reliably).
 *
 * Fall detection algorithm (Apple-inspired, 5-phase):
 *  Phase 1 – Free-fall:    |a| < FREE_FALL_THRESHOLD (~0 g)
 *  Phase 2 – Impact:       |a| ≥ IMPACT_THRESHOLD within IMPACT_WINDOW_MS
 *  Phase 3 – Rotation:     gyro angular velocity > GYRO_THRESHOLD within GYRO_WINDOW_MS
 *  Phase 4 – Inactivity:   |a| stays low for INACTIVITY_DURATION_MS
 *  Phase 5 – Alert:        FallAlertActivity fires via full-screen notification
 */
class FallDetectionService : Service(), SensorEventListener {

    // ── Sensors ───────────────────────────────────────────────────────────────
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var gyroscope: Sensor? = null
    private var temperatureSensor: Sensor? = null

    // ── WakeLock — keeps CPU alive while sensors run and during alert launch ──
    private var wakeLock: android.os.PowerManager.WakeLock? = null

    // ── State machine ─────────────────────────────────────────────────────────
    private enum class State {
        MONITORING, FREE_FALL_DETECTED, IMPACT_DETECTED, ROTATION_CONFIRMED
    }
    private var state = State.MONITORING

    private var freeFallTime  = 0L
    private var impactTime    = 0L
    private var lowAccStart   = 0L

    // ── Temperature tracking ──────────────────────────────────────────────────
    private var lastTemperature  = Float.NaN
    private var tempDropStart    = 0L
    private var tempAtDropStart  = Float.NaN
    private var tempAlertFired   = false   // prevents repeated alerts from one episode

    // ── Tuneable thresholds ───────────────────────────────────────────────────
    companion object {
        private const val CHANNEL_ID      = "fall_detection_channel"
        private const val NOTIFICATION_ID = 1001
        private const val ALERT_NOTIF_ID  = 1002

        /** True while the service is alive in this process. Used by FallDetectionWatchdog. */
        @Volatile var isRunning = false

        // ── Phase 1 — free-fall (was 3.0 → raised to avoid pocket jerk triggering)
        private const val FREE_FALL_THRESHOLD    = 2.0f    // m/s² (≈ 0.2 g)

        // ── Phase 2 — impact (was 23.5 → 30 m/s² ≈ 3 g — real falls hit much harder)
        private const val IMPACT_THRESHOLD       = 30.0f   // m/s²
        private const val IMPACT_WINDOW_MS       = 700L

        // ── Phase 3 — rotation (was 4.19 rad/s → same, window tightened)
        private const val GYRO_THRESHOLD         = 4.50f   // rad/s  (~258 °/s)
        private const val GYRO_WINDOW_MS         = 400L    // 500 → 400 ms

        // ── Phase 4 — inactivity (was 1500 → 2500 ms: need longer stillness to confirm)
        private const val IDLE_THRESHOLD         = 11.0f   // m/s²
        private const val INACTIVITY_DURATION_MS = 2500L

        // ── Temperature monitoring
        // If body temp drops by ≥ 2 °C within 60 s, flag as potential medical event
        private const val TEMP_DROP_THRESHOLD    = 2.0f    // °C
        private const val TEMP_WINDOW_MS         = 60_000L // 60 seconds

        fun startService(context: Context) {
            context.getSharedPreferences(BootReceiver.PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(BootReceiver.KEY_FALL_DETECTION_ENABLED, true).apply()
            val intent = Intent(context, FallDetectionService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                context.startForegroundService(intent)
            else
                context.startService(intent)
        }

        fun stopService(context: Context) {
            context.getSharedPreferences(BootReceiver.PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(BootReceiver.KEY_FALL_DETECTION_ENABLED, false).apply()
            context.stopService(Intent(context, FallDetectionService::class.java))
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildStatusNotification())

        // Partial WakeLock: keeps the CPU running (and sensors delivering events)
        // even when the screen is off and the device would otherwise deep-sleep.
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        wakeLock = pm.newWakeLock(
            android.os.PowerManager.PARTIAL_WAKE_LOCK,
            "NearHand:FallDetectionWakeLock"
        ).also { it.acquire() }

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }

        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        gyroscope?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }

        // Ambient / body temperature sensor (TYPE_AMBIENT_TEMPERATURE is the standard;
        // some Wear OS and medical-grade devices expose TYPE_BODY_TEMPERATURE).
        // We try body first, fall back to ambient — both signal dangerous cold episodes.
        temperatureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)
        temperatureSensor?.let {
            // Normal (not GAME) rate is fine for temperature — it changes slowly
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onDestroy() {
        isRunning = false
        wakeLock?.let { if (it.isHeld) it.release() }
        sensorManager.unregisterListener(this)
        super.onDestroy()
    }

    /**
     * Make sure the system keeps this service running even if it gets killed
     * for memory, and that it is restarted automatically with the same intent.
     * This is what allows fall detection to keep working when the app is
     * "closed" (swiped from recents) or the device is locked.
     */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    /**
     * Called when the user swipes the app away from Recents. Without this,
     * some OEM launchers will kill the foreground service along with the task.
     * We immediately restart the service so monitoring continues uninterrupted.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val restartIntent = Intent(applicationContext, FallDetectionService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            applicationContext.startForegroundService(restartIntent)
        } else {
            applicationContext.startService(restartIntent)
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Sensor callback ───────────────────────────────────────────────────────
    override fun onSensorChanged(event: SensorEvent) {
        val now = System.currentTimeMillis()
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER    -> handleAccelerometer(event, now)
            Sensor.TYPE_GYROSCOPE        -> handleGyroscope(event, now)
            Sensor.TYPE_AMBIENT_TEMPERATURE -> handleTemperature(event, now)
        }
    }

    private fun handleAccelerometer(event: SensorEvent, now: Long) {
        val mag = magnitude(event.values)

        when (state) {
            State.MONITORING -> {
                if (mag < FREE_FALL_THRESHOLD) {
                    state = State.FREE_FALL_DETECTED
                    freeFallTime = now
                }
            }

            State.FREE_FALL_DETECTED -> {
                if (now - freeFallTime > IMPACT_WINDOW_MS) {
                    state = State.MONITORING; return
                }
                if (mag > IMPACT_THRESHOLD) {
                    state = State.IMPACT_DETECTED
                    impactTime  = now
                    lowAccStart = now
                }
            }

            State.IMPACT_DETECTED -> {
                if (now - impactTime > GYRO_WINDOW_MS) {
                    state = if (gyroscope == null) {
                        lowAccStart = now
                        State.ROTATION_CONFIRMED
                    } else {
                        State.MONITORING
                    }
                }
            }

            State.ROTATION_CONFIRMED -> {
                if (mag > IDLE_THRESHOLD) {
                    lowAccStart = now   // person moved → reset inactivity clock
                }
                if (now - lowAccStart >= INACTIVITY_DURATION_MS) {
                    triggerFallAlert()
                    state = State.MONITORING
                }
            }
        }
    }

    private fun handleGyroscope(event: SensorEvent, now: Long) {
        if (state != State.IMPACT_DETECTED) return
        if (now - impactTime > GYRO_WINDOW_MS) return
        val angVel = magnitude(event.values)
        if (angVel > GYRO_THRESHOLD) {
            state = State.ROTATION_CONFIRMED
            lowAccStart = now
        }
    }

    private fun handleTemperature(event: SensorEvent, now: Long) {
        val temp = event.values[0]

        if (lastTemperature.isNaN()) {
            // First reading — just record it
            lastTemperature = temp
            tempAtDropStart = temp
            tempDropStart = now
            return
        }

        // Track cumulative drop within the monitoring window
        val elapsed = now - tempDropStart
        if (elapsed > TEMP_WINDOW_MS) {
            // Reset window
            tempAtDropStart = temp
            tempDropStart   = now
            tempAlertFired  = false
        }

        val drop = tempAtDropStart - temp   // positive = cooling
        if (drop >= TEMP_DROP_THRESHOLD && !tempAlertFired) {
            tempAlertFired = true
            triggerFallAlert(isTempEvent = true)
        }

        lastTemperature = temp
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) { /* no-op */ }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun magnitude(v: FloatArray): Float =
        sqrt((v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).toDouble()).toFloat()

    /**
     * Trigger the fall alert.
     *
     * On Android 10+, activities can no longer be launched directly from background
     * services unless the app has SYSTEM_ALERT_WINDOW or similar privileges.
     * The reliable, OS-approved approach is to fire a HIGH-importance notification
     * that carries a full-screen intent.  Android will:
     *  • Show the activity immediately if the device is locked / screen-off.
     *  • Show a heads-up notification if the device is in use (over any app).
     *
     * This makes the alert work on lock screen AND over other apps.
     */
    private fun triggerFallAlert(isTempEvent: Boolean = false) {
        val alertIntent = Intent(this, FallAlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            putExtra(FallAlertActivity.EXTRA_IS_TEMP_EVENT, isTempEvent)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else
            PendingIntent.FLAG_UPDATE_CURRENT

        val fullScreenPi = PendingIntent.getActivity(this, 0, alertIntent, flags)

        val nm = getSystemService(NotificationManager::class.java)
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_fall_detection)
            .setContentTitle(getString(R.string.fall_detected_title))
            .setContentText(getString(R.string.fall_detected_subtitle))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreenPi, true)   // ← key: shows over lock screen & apps
            .setAutoCancel(true)
            .build()

        nm.notify(ALERT_NOTIF_ID, notif)

        // Always launch FallAlertActivity directly so it appears as a true full-screen
        // overlay on all API levels, not just as a heads-up notification banner.
        // FLAG_ACTIVITY_NEW_TASK is required to start an activity from a Service context.
        // The full-screen notification intent above still handles the lock-screen path.
        startActivity(alertIntent)
    }

    // ── Foreground notification ───────────────────────────────────────────────
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Fall Detection",
                NotificationManager.IMPORTANCE_HIGH   // HIGH so full-screen intents work
            ).apply {
                description = "Monitors for accidental falls in the background"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildStatusNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.fall_detection_active))
            .setContentText(getString(R.string.fall_detection_monitoring))
            .setSmallIcon(R.drawable.ic_fall_detection)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }
}
