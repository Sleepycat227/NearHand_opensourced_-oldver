package com.nearhand.app.doctor

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import com.nearhand.app.BaseActivity
import com.nearhand.app.R
import com.nearhand.app.databinding.ActivityCallDoctorBinding

/**
 * CallDoctorActivity
 *
 * Entry point for the "Call Your Doctor" feature.
 *
 * Flow A – first launch (no doctor saved):
 *   The activity shows a full-screen prompt explaining that a trusted person
 *   (family member / caregiver) should set up the doctor contact.  A single
 *   prominent button opens DoctorSetupActivity.  Once setup is complete the
 *   UI refreshes to Flow B.
 *
 * Flow B – doctor already saved:
 *   The activity shows the saved doctor's name, a large "Video Call" button,
 *   and a small edit icon.  Tapping the video call button:
 *     1. Checks CALL_PHONE permission (needed to confirm the user can make calls).
 *     2. Launches a video call via the system's built-in video call intent
 *        (vnd.android.cursor.item/video_call), which hands off to whatever
 *        video-calling app the user has set as default (Google Meet, WhatsApp,
 *        etc.).  If no app supports that intent we fall back to a regular
 *        voice call so the user is never left stranded.
 *
 * Design decisions:
 *   • We use SharedPreferences (via DoctorSetupActivity.PREFS) — no server
 *     needed, works offline, instant reads.
 *   • Video call intent: Android has no universal "video call" deep-link that
 *     works across all carriers and apps, so we try the standard
 *     video-call MIME-type intent first, then fall back to ACTION_CALL.
 *     WhatsApp / FaceTime / Google Meet each have their own URI schemes; we
 *     avoid hard-coding any one of them so the user's default app wins.
 */
class CallDoctorActivity : BaseActivity() {

    private lateinit var binding: ActivityCallDoctorBinding

    // ── Permission launcher ───────────────────────────────────────────────────

    private val callPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) placeVideoCall()
        else showPermissionDeniedDialog()
    }

    // ── Setup result launcher ─────────────────────────────────────────────────

    private val setupLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) refreshUi()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCallDoctorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSetupDoctor.setOnClickListener {
            setupLauncher.launch(Intent(this, DoctorSetupActivity::class.java))
        }
        binding.btnEditDoctor.setOnClickListener {
            setupLauncher.launch(Intent(this, DoctorSetupActivity::class.java))
        }
        binding.btnVideoCall.setOnClickListener { onCallTapped() }

        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    // ── UI state ──────────────────────────────────────────────────────────────

    private fun refreshUi() {
        val prefs      = getSharedPreferences(DoctorSetupActivity.PREFS, Context.MODE_PRIVATE)
        val savedName  = prefs.getString(DoctorSetupActivity.KEY_NAME,  "") ?: ""
        val savedPhone = prefs.getString(DoctorSetupActivity.KEY_PHONE, "") ?: ""
        val hasDoctor  = savedName.isNotEmpty() && savedPhone.isNotEmpty()

        // Toggle between "setup needed" and "ready to call" panels
        binding.layoutSetupNeeded.visibility =
            if (hasDoctor) android.view.View.GONE else android.view.View.VISIBLE
        binding.layoutCallReady.visibility   =
            if (hasDoctor) android.view.View.VISIBLE else android.view.View.GONE

        if (hasDoctor) {
            binding.tvDoctorName.text  = savedName
            binding.tvDoctorPhone.text = savedPhone
        }
    }

    // ── Call logic ────────────────────────────────────────────────────────────

    private fun onCallTapped() {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            placeVideoCall()
        } else {
            callPermissionLauncher.launch(Manifest.permission.CALL_PHONE)
        }
    }

    /**
     * Attempt a video call via the standard Android video-call intent.
     * Falls back to a regular voice call if no app handles the video intent.
     */
    private fun placeVideoCall() {
        val prefs = getSharedPreferences(DoctorSetupActivity.PREFS, Context.MODE_PRIVATE)
        val phone = prefs.getString(DoctorSetupActivity.KEY_PHONE, "") ?: return

        // Try video call intent first (handled by Duo / Meet / WhatsApp etc.)
        val videoIntent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("tel:$phone")
            type = "vnd.android.cursor.item/video_call"
        }

        if (videoIntent.resolveActivity(packageManager) != null) {
            startActivity(videoIntent)
        } else {
            // Fallback: place a regular voice call
            val voiceIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phone"))
            startActivity(voiceIntent)
        }
    }

    private fun showPermissionDeniedDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.doctor_call_permission_title)
            .setMessage(R.string.doctor_call_permission_message)
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }
}
