package com.nearhand.app.helper

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.nearhand.app.BaseActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import com.nearhand.app.databinding.ActivityRequestDetailBinding
import com.nearhand.app.model.RequestType
import com.nearhand.app.utils.FirebaseRepository
import kotlinx.coroutines.launch

class RequestDetailActivity : BaseActivity() {

    private lateinit var binding: ActivityRequestDetailBinding
    private var elderPhone = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRequestDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val requestId   = intent.getStringExtra("requestId") ?: return
        val elderName   = intent.getStringExtra("elderName") ?: ""
        val type        = intent.getStringExtra("type") ?: ""
        val description = intent.getStringExtra("description") ?: ""
        val status      = intent.getStringExtra("status") ?: "open"
        val address     = intent.getStringExtra("address") ?: ""
        elderPhone      = intent.getStringExtra("elderPhone") ?: ""

        val requestType = runCatching { RequestType.valueOf(type) }.getOrNull()
        binding.tvEmoji.text       = requestType?.emoji ?: "🙏"
        binding.tvType.text        = requestType?.displayName ?: type
        binding.tvElderName.text   = "From: $elderName"
        binding.tvDescription.text = description.ifEmpty { "No additional details provided." }
        binding.tvStatus.text      = "Status: ${status.replaceFirstChar { it.uppercase() }}"

        // Address
        if (address.isNotEmpty()) {
            binding.tvAddress.visibility = View.VISIBLE
            binding.tvAddress.text = "📍 $address"
        } else {
            binding.tvAddress.visibility = View.GONE
        }

        // Call button
        if (elderPhone.isNotEmpty()) {
            binding.btnCall.visibility = View.VISIBLE
            binding.btnCall.setOnClickListener {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$elderPhone"))
                startActivity(intent)
            }
        } else {
            binding.btnCall.visibility = View.GONE
        }

        if (status != "open") binding.btnAccept.visibility = View.GONE

        binding.btnAccept.setOnClickListener { acceptRequest(requestId, elderName) }
    }

    private fun acceptRequest(requestId: String, elderName: String) {
        binding.btnAccept.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            FirebaseRepository.getCurrentUser()
                .onSuccess { helper ->
                    FirebaseRepository.updateRequestStatus(
                        requestId  = requestId,
                        status     = "accepted",
                        helperUid  = helper.uid,
                        helperName = helper.name
                    ).onSuccess {
                        binding.progressBar.visibility = View.GONE
                        binding.btnAccept.visibility   = View.GONE
                        binding.tvStatus.text = "Status: Accepted ✅"
                        Snackbar.make(binding.root, "You've accepted this request! Please reach out to $elderName 💛", Snackbar.LENGTH_LONG).show()
                    }.onFailure {
                        binding.progressBar.visibility = View.GONE
                        binding.btnAccept.isEnabled    = true
                        Snackbar.make(binding.root, "Failed to accept. Try again.", Snackbar.LENGTH_LONG).show()
                    }
                }
                .onFailure {
                    binding.progressBar.visibility = View.GONE
                    binding.btnAccept.isEnabled    = true
                }
        }
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}
