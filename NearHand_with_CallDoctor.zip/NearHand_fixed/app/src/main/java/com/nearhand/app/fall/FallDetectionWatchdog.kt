package com.nearhand.app.fall

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * FallDetectionWatchdog
 *
 * A periodic WorkManager job that runs every 15 minutes (the minimum interval
 * the OS allows) and checks whether FallDetectionService is still alive.
 * If the OS killed the process (OOM killer, forced stop by OEM task manager,
 * etc.) this job restarts it automatically — without requiring the user to
 * open the app again.
 *
 * WorkManager survives:
 *  • App swipe-from-recents   (already covered by onTaskRemoved, belt-and-braces)
 *  • OS OOM process kill
 *  • Device reboot            (WorkManager re-enqueues itself after boot automatically)
 *
 * It does NOT survive a user explicitly force-stopping the app from Settings →
 * Apps → NearHand → Force Stop. That is an intentional OS restriction; no
 * third-party app can circumvent it, and doing so would be a policy violation.
 */
class FallDetectionWatchdog(
    private val context: Context,
    workerParams: WorkerParameters
) : Worker(context, workerParams) {

    override fun doWork(): Result {
        val prefs = context.getSharedPreferences(BootReceiver.PREFS_NAME, Context.MODE_PRIVATE)
        val shouldBeRunning = prefs.getBoolean(BootReceiver.KEY_FALL_DETECTION_ENABLED, false)

        if (shouldBeRunning && !FallDetectionService.isRunning) {
            FallDetectionService.startService(context)
        }

        return Result.success()
    }

    companion object {
        private const val WORK_NAME = "fall_detection_watchdog"

        /**
         * Schedule (or re-confirm) the periodic watchdog.
         * Call this from NearHandApp.onCreate() and from ElderHomeActivity when
         * fall detection is enabled.
         * KEEP_EXISTING means a running schedule is never disturbed — we only
         * install it once.
         */
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<FallDetectionWatchdog>(
                15, TimeUnit.MINUTES
            )
                .setConstraints(Constraints.Builder().build()) // no constraints — must run always
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
