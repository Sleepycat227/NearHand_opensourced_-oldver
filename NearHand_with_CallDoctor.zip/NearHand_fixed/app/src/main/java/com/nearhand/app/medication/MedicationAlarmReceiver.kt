package com.nearhand.app.medication

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.nearhand.app.NearHandApp
import com.nearhand.app.R

class MedicationAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val medName     = intent.getStringExtra("medName") ?: "your medication"
        val dosage      = intent.getStringExtra("dosage") ?: ""
        val instructions = intent.getStringExtra("instructions") ?: ""
        val notifId     = intent.getIntExtra("notifId", 0)

        val openIntent = Intent(context, MedicationListActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context, notifId, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val bodyText = buildString {
            append("Time to take $medName")
            if (dosage.isNotEmpty()) append(" — $dosage")
            if (instructions.isNotEmpty()) append(". $instructions")
        }

        val notification = NotificationCompat.Builder(context, NearHandApp.CHANNEL_MEDICATION)
            .setSmallIcon(R.drawable.ic_medication)
            .setContentTitle("💊 Medication Reminder")
            .setContentText(bodyText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bodyText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(longArrayOf(0, 500, 250, 500))
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(notifId, notification)
    }
}
